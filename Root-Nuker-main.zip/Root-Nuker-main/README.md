# Root-Nuker
Root nuker released here you go skids


# made by Yum & Dux

give credits retard.

#  
releasing this cus im quitting cord

